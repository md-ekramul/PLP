package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.*;
import com.cg.service.*;

@RestController  
public class UpdateStatusController {

	@Autowired
	UpdateStatus service;
	
	@RequestMapping(value="/setDefaultStatus")
		public void setDefaultStatus(int id) {
		OrderDetails order=service.setDefaultStatus(id);
	}
	
	@RequestMapping(value="/updateStatus")
	public void updateStatus( int id) {
	service.updateStatus(id);
	}
	
	@RequestMapping(value="/displayDeliveryStatus")
	public String displayDeliveryStatus(int order_id) {
	return service.displayDeliveryStatus(order_id);
}
}
