package com.cg.service;

import com.cg.model.*;

public interface UpdateStatus {

	public OrderDetails setDefaultStatus(int id);
    public void updateStatus(int id);
    public String displayDeliveryStatus(int order_id);
	
}